print("Mata in ett tal")
tal1 = int(input())
print("Mata in ett tal till")
tal2 = int(input())

print("Summan av ",tal1, " and ",tal2, " is:",tal1+tal2)
print("Differens av ",tal1, " and ",tal2, " is:",tal1-tal2)
print("Medel av ",tal1, " and ",tal2, " is:",(tal1+tal2)/2)


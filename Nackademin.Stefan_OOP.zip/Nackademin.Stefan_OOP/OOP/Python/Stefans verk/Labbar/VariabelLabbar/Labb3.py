myName = "Stefan"
age = 45
print("MItt namn är ", myName, " och jag är ", age , " år")



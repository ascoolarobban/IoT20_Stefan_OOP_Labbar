mittName = "Stefan"
print("Hello ", mittNamn)  




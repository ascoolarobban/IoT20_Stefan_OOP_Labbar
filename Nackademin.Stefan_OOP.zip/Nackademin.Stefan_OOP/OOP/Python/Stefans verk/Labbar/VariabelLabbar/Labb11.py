
totalMinuter = int(input("mata in antal minuter:"))
timmar = totalMinuter // 60
minuter = totalMinuter % 60

print("Det är ", timmar, " timmar och ", minuter, " minuter")



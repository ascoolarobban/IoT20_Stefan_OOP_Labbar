
age = int(input("Ange ålder"))
if age >=1980 and age < 1990:
    print("Du är född på 1980-talet")
elif age >=1990 and age < 2000:
    print("Du är född på 1990-talet")
else:
    print("Du är inte född på 1990 eller 1980-talen")
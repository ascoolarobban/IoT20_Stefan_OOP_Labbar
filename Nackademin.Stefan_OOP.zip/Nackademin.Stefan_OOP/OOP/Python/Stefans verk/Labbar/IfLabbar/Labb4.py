age = int(input("Mata in din ålder:"))
if age > 65:
    print("Pensionär")
elif age > 18:
    print("Myndig")
else:
    print("Ej myndig")

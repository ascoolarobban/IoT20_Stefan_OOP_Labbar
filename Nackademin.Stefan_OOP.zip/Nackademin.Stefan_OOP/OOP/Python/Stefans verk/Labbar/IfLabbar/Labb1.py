
tal = input("Mata in ett tal")
if tal > 10:
    print("Större än 10")
elif tal < 10:
    print("Mindre än 10")

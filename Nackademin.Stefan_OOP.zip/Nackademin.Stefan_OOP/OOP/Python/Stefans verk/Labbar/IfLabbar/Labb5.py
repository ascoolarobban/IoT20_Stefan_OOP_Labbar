kat = input("Ange kategori")

if kat == "pensionär" or kat == "student":
    print("Priset är 20")
elif kat == "vuxen":
    print("Priset är 30")
else:
    print("Du har matat in fel kategori")




land = input("Ange land:")

if land == "Sverige" or land == "Danmark" or land == "Norge":
    print("Du bor i Skandinavien")
else:
    print("Du bor inte i Skandinavien")

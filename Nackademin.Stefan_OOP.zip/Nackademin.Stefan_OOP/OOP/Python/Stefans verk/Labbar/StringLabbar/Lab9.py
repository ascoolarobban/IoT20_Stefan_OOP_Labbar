
inmatning = input("Skriv in en text")

words = inmatning.split(" ")
print(len(words))
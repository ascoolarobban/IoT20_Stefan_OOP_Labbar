s = "Hello, world"
pos = s.find("w")
print(pos)

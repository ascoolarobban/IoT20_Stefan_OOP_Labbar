
s = ""
for i in range(0,3):
    s = s + input("Mata in sträng")
print(f"Detta blir {s}")



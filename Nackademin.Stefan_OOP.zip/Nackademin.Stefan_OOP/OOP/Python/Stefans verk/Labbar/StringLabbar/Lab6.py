hela = "ett,två,tre,fyra,fem,sex,sju"
arr = hela.split(',')
for part in arr:
    print(part)

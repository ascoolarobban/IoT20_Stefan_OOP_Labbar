def AddTwoNumbers(number1, number2):
    #return number1 + number2
    print(number1+number2)


s = AddTowNumbers(1,2)
print("Det blev {s}")


def PrintMessage():
    return "Hello World"

print(PrintMessage())




with open("hej.txt", "r") as filen:
    for line in filen:
        print(f"Rad i filen:{line}")

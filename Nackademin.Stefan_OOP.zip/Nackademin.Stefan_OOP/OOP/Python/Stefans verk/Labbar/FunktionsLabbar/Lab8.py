
def sum(talLista):
    sum = 0
    for tal in talLista:
        sum += tal
    return sum

def multiply(talLista):
    mult = 1
    for tal in talLista:
        mult *= tal
    return mult


def test2(num):
    num = 123

def test(talLista):
    talLista.append(100)

lista = [1,6,3,4]

test(lista)


print(sum(lista))
print(multiply(lista))

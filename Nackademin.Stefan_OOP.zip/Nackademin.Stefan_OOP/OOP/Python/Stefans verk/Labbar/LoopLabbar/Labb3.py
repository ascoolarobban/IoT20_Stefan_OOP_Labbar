while True:
    tal1 = int(input("Mata in tal1"))
    tal2 = int(input("Mata in tal2"))

    print(f"summan av {tal1} och {tal2} är {tal1+tal2}")
    fortsatt = input("Vill du fortsätta? J/N")
    if fortsatt == "N":
        break
    #TODO Vi gör en till loop - ogiltig inmatning


tal1 = int(input("Mata in tal1"))
tal2 = int(input("Mata in tal2"))


for i in range(tal1+1,tal2):
    print(i)


#Tal 2 större - räkna baklänges
for i in range(100,50,-1):
    print(i)
#alt1
for i in range(0,100):
    if i % 2 == 1:
        print(i)

#alt2
for i in range(1,100,2):
    print(i)

summa = 0

for i in range(1,11):
    tal1 = int(input(f"Mata in tal nr{i}:"))
    #summa = summa + tal1
    summa += tal1

print(f"summan blir {summa}")

lista = [1123,234,423]
for i in lista:
    print(i)

print("Bästa spelaren 11 ggr" )
for i in range(11):
    print("Mats Sundin")


i = 18
i = i + 12
print("Hello")
i = i + 13


for i in range(11):
    print(i)


gameOver = False
while gameOver == False:
    print("312313")
    print("sdfasda")


import datetime

datum = datetime.datetime.now()

print(datum.strftime("%Y-%m-%d %H:%M:%S"))
print(datum.strftime("%Y-%m-%d"))

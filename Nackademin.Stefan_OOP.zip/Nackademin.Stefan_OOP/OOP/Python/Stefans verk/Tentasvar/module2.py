

while True:
    s = input("mata in text")
    if len(s) >40 or s == "":
        break
    while len(s) < 40:
        s = " " + s
    print(s)


class Organization:
    def __init__(self, namn, gatuadress, ort, webadress):
        self._namn = namn
        self._gatuadress = gatuadress
        self._ort = ort
        self._webadress = webadress
        self._manager = None
    def SetManager(self,employee):
        self._manager = employee

class Employee:
    def __init__(self, personnummer, fornamn, efternamn):
        self._personnummer = personnummer
        self._fornamn = fornamn
        self._efternamn = efternamn

e = Employee("333131","Stefan","Holmberg")
o = Organization("2313","testg","331","www")
o.SetManager(e)



longest = ""
shortest = ""
ordLista = input("mata in text").split()
for s in ordLista:
    if len(s) > len(longest):
        longest = s
    if shortest == "" or len(s) < len(shortest):
        shortest = s

print(f"Longest: {longest}   Shortest:{shortest}")

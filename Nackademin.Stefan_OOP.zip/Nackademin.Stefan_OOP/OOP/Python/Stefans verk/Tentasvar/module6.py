from abc import ABC, abstractmethod

class Fastighet:
    def __init__(self, boyta, taxvarde):
        self._boyta = boyta
        self._taxvarde = taxvarde

    @abstractmethod
    def GetFastighetsavgift(self):
        pass

class Villa(Fastighet):
    def __init__(self, boyta, taxvarde):
        super().__init__(boyta,taxvarde)

    def GetFastighetsavgift(self):
        v = self._taxvarde/100 * 0.75
        if v > 7112:
            v = 7112
        return v

class Lagenhet(Fastighet):
    def __init__(self, boyta, taxvarde):
        super().__init__(boyta,taxvarde)

    def GetFastighetsavgift(self):
        v = self._taxvarde/100 * 0.3
        if v > 1217:
            v = 1217
        return v

v = Villa(128,3000000)
print(v.GetFastighetsavgift())

lv = Lagenhet(128,45000)
print(lv.GetFastighetsavgift())
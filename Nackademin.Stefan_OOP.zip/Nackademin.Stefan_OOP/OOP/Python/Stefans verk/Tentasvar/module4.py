def Total(lista):
    sum = 0
    for i in lista:
        sum = sum + len(i)
    return sum



cities = [ "Stockholm", "Göteborg", "Malmö", "Köpenhamn", "London" ]
print(Total(cities))


from datetime import datetime

class Person:
    def __init__(self, namn, birthDate):
        self._namn = namn
        self._birthDate = birthDate

    def GetNamn(self):
        return self._namn

    def GetDays(self):
        td = datetime.now() - self._birthDate
        return td.days

lista = []
antal = int(input("Antal personer"))
for i in range(0,antal):
    namn = input(f"Vad heter person {i+1}?")
    d = datetime.strptime(input(f"När är person {i+1} född"),"%Y-%m-%d")
    lista.append(Person(namn,d))

for l in lista:
    print(f"{l.GetNamn()} är {l.GetDays()}")


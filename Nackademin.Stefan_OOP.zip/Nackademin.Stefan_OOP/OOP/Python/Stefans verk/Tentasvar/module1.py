tal = [ -9, 3, 7, 2, 1, 3, 4, 4, 2, 5, 75, 4, 2, 67 ]

nylista = []
for i in tal:
    if i % 2 == 1 and not i in nylista:
        nylista.append(i)

nylista.sort()
nylista.reverse()
for h in nylista:
    print(h)


import random

lista = [   "MacGyver",
            "MacGonagall",
            "MacDonald",
            "Macahan",
            "MacThurbo",
            "Pascal",
            "Pilot",
            "PingPong",
            "Kristall",
            "Pucko",
            "Prinsessa",
            "Bubblan",
            "Fjollan",
            "Filur",
            "Baron von Münchausen",
            "Tiny Toledo",
            "Zelda",
            "Miss Maxina",
            "Zolita",
            "Oscar",
            "Leya",
            "Tequila",
            "Sunrise",
            "Bruce",
            "Lennart",
            "Greger",
            "Gunnar",
            "Gunnel",
            "Blåbär",
            "Billy",
            "Bob",
            "Sigbritt"
         ]


def GetAnimalName( minChars, maxChars ):
    listaCorrectLen = []
    for i in lista:
        if len(i) >= minChars and len(i) <= maxChars:
            listaCorrectLen.append(i)

    if len(listaCorrectLen) == 0:
        return None
    return listaCorrectLen[random.randrange(0,len(listaCorrectLen))]


print(GetAnimalName(7,9) )
print(GetAnimalName(1,1) )
print(GetAnimalName(2,9) )